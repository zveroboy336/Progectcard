import flet as ft









a = 'dark'
b = 'True'
c = '40000'
d = '₽'
banks = ["Сбербанк", "ВТБ", "Тинькофф", "Альфа-банк"]